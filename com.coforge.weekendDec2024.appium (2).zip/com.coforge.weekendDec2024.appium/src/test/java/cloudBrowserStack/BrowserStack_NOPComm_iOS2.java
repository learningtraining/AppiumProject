package cloudBrowserStack;

import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.appium.java_client.remote.MobileBrowserType;
import io.appium.java_client.remote.MobileCapabilityType;
import utility.Constants;

public class BrowserStack_NOPComm_iOS2 {
	
	
	WebDriver driver;
	public static final String USERNAME = Constants.bs_userName;
	public static final String AUTOMATE_KEY = Constants.bs_accesskey;
	public static final String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";

	
	
	
	@BeforeMethod
	public void setUp() throws Exception {

		
		DesiredCapabilities caps = new DesiredCapabilities();
        
		caps.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone 13");
		caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "OS X");
		//caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "14");
		
		
		caps.setCapability(MobileCapabilityType.BROWSER_NAME, MobileBrowserType.SAFARI);
		caps.setCapability(MobileCapabilityType.BROWSER_VERSION, "15.6");
		
		
		caps.setCapability("build", "cofoge_iOS - v101");
		caps.setCapability("name", "Coforge Automation - Run on device - NOP comm Test on cloud -iOS");

		driver = new RemoteWebDriver(new URL(URL), caps);

	}

	
	
	
	@Test
	public void LaunchNOPCommApp() throws Exception {
		Thread.sleep(3000);
		driver.get("https://admin-demo.nopcommerce.com/login?ReturnUrl=%2Fadmin%2F");
		Thread.sleep(3000);
		
		driver.findElement(By.cssSelector("input#Email")).clear();
		driver.findElement(By.cssSelector("input#Email")).sendKeys("admin@yourstore.com");
		
		driver.findElement(By.name("Password")).clear();
		driver.findElement(By.name("Password")).sendKeys("admin");
		
		driver.findElement(By.cssSelector("input#RememberMe")).click();
		
		driver.findElement(By.tagName("button")).click();
		
		Thread.sleep(5000);
		
		driver.findElement(By.cssSelector("span.navbar-toggler-icon")).click();
		
		Thread.sleep(5000);
		
		//driver.findElement(By.partialLinkText("Logout")).click();
		
	}
	
	
	@AfterMethod(alwaysRun = true)
	public void tearDown() {
		driver.quit();
	}
	
	
	

}
