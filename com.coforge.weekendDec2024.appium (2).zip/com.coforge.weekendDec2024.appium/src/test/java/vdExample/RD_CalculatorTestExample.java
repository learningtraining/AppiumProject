package vdExample;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class RD_CalculatorTestExample {
	
//	AppiumDriver driver;
	AppiumDriver<MobileElement> driver;
	
	@BeforeTest
	public void setup() throws Exception {
		
		System.out.println("connecting to devices");
		String AppiumServer = "http://localhost:4723/wd/hub";
		
		
		DesiredCapabilities caps = new DesiredCapabilities();
		
		//DevicesDetails
		caps.setCapability("udid", "c60c1a73");								//adb devices
		caps.setCapability("platformName", "Android");
		caps.setCapability("platformVersion", "13.0");
		caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "13.0");
		
		//ApplicationDetails
		caps.setCapability("appPackage", "com.google.android.calculator");
		caps.setCapability("appActivity", "com.android.calculator2.Calculator");
		
		//create a device session
		driver = new AppiumDriver<MobileElement>(new URL(AppiumServer), caps);     
		
	}
	
	
	
	
	@AfterTest
	public void teardown() throws Exception {
		Thread.sleep(5000);
		driver.closeApp();
		System.out.println("dis-connecting to devices");
	}
	
	
	
	
	
	
	@Test
	public void verifyAddTest() {
		
		driver.findElement(By.id("clr")).click();
		System.out.println("executing test case on real device");
		driver.findElement(By.id("digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_8")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		
		
		//com.google.android.calculator:id/digit_9
		
		//click on Plus button
		driver.findElement(By.id("op_add")).click();
		
		
		driver.findElement(By.id("digit_9")).click();
		driver.findElement(By.id("digit_9")).click();
		driver.findElement(By.id("digit_9")).click();
		driver.findElement(By.id("digit_9")).click();
		driver.findElement(By.id("digit_8")).click();
		driver.findElement(By.id("digit_9")).click();
		
		
		//click on equal button
		driver.findElement(By.id("eq")).click();
		
		
		//Fetch the test results 
		String actualResult = driver.findElement(By.id("result_final")).getText();
		System.out.println("Add Test Results are: " + actualResult);
		//Validation test
		
		Assert.assertEquals(actualResult, "1989988");
		
	}
	
	@Test
	public void verifyMulTest() {
		
		driver.findElement(By.id("clr")).click();
		System.out.println("executing test case on real device");
		driver.findElement(By.id("digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_8")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		
		
		//com.google.android.calculator:id/digit_9
		
		//click on Plus button
		driver.findElement(By.id("op_mul")).click();
		
		
		driver.findElement(By.id("digit_9")).click();
		driver.findElement(By.id("digit_9")).click();
		driver.findElement(By.id("digit_9")).click();
		driver.findElement(By.id("digit_9")).click();
		driver.findElement(By.id("digit_8")).click();
		driver.findElement(By.id("digit_9")).click();
		
		
		//click on equal button
		driver.findElement(By.id("eq")).click();
		
		
		//Fetch the test results 
		String actualResult = driver.findElement(By.id("result_final")).getText();
		System.out.println("Mul Test Results are: " + actualResult);
		//Validation test
		
		Assert.assertEquals(actualResult, "123712312");
		
	}
	
	
	@Test
	public void verifySubTest() {
		
		driver.findElement(By.id("clr")).click();
		System.out.println("executing test case on real device");
		driver.findElement(By.id("digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_8")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		
		
		//com.google.android.calculator:id/digit_9
		
		//click on Plus button
		driver.findElement(By.id("op_sub")).click();
		
		
		driver.findElement(By.id("digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_8")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_8")).click();
		
		
		//click on equal button
		driver.findElement(By.id("eq")).click();
		
		
		//Fetch the test results 
		String actualResult = driver.findElement(By.id("result_final")).getText();
		System.out.println("Sub Test Results are: " + actualResult);
		//Validation test
		
		Assert.assertEquals(actualResult, "1");
		
	}
	
	
	@Test
	public void verifyDivTest() {
		
		System.out.println("executing test case on real device");
		
		driver.findElement(By.id("clr")).click();
		
		driver.findElement(By.id("digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_8")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		
		
		//com.google.android.calculator:id/digit_9
		
		//click on Plus button
		driver.findElement(By.id("op_div")).click();
		
		
		driver.findElement(By.id("digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_8")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		driver.findElement(By.id("com.google.android.calculator:id/digit_9")).click();
		
		
		//click on equal button
		driver.findElement(By.id("eq")).click();
		
		
		//Fetch the test results 
		String actualResult = driver.findElement(By.id("result_final")).getText();
		System.out.println("Div Test Results are: " + actualResult);
		//Validation test
		
		Assert.assertEquals(actualResult, "1");
		
	}

}
